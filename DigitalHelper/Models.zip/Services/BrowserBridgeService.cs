using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using DigitalHelper.Models;

namespace DigitalHelper.Services
{
    /// <summary>
    /// WebSocket server that bridges communication between WPF app and Chrome extension
    /// </summary>
    public class BrowserBridgeService
    {
        private static readonly Lazy<BrowserBridgeService> _instance = new Lazy<BrowserBridgeService>(() => new BrowserBridgeService());
        public static BrowserBridgeService Instance => _instance.Value;

        private HttpListener? _httpListener;
        private WebSocket? _webSocket;
        private bool _isRunning = false;
        private Task? _listenerTask;
        private DomSummary? _lastDomSummary;
        private TaskCompletionSource<DomSummary>? _domRequestCompletion;
        private readonly SemaphoreSlim _domRequestLock = new SemaphoreSlim(1, 1);
        private Timer? _keepAliveTimer;
        private const int KEEPALIVE_INTERVAL_MS = 15000; // Send ping every 15 seconds

        public bool IsConnected => _webSocket != null && _webSocket.State == WebSocketState.Open;

        private BrowserBridgeService()
        {
        }

        /// <summary>
        /// Start the WebSocket server
        /// </summary>
        public async Task StartAsync()
        {
            if (_isRunning) return;

            _isRunning = true;
            _listenerTask = Task.Run(RunServerAsync);
            await Task.Delay(100); // Give server time to start
        }

        /// <summary>
        /// Stop the WebSocket server
        /// </summary>
        public async Task StopAsync()
        {
            _isRunning = false;

            // Stop keepalive timer
            _keepAliveTimer?.Dispose();
            _keepAliveTimer = null;

            if (_webSocket != null && _webSocket.State == WebSocketState.Open)
            {
                await _webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Server shutting down", CancellationToken.None);
            }

            _httpListener?.Stop();
            _httpListener?.Close();
        }

        /// <summary>
        /// Request DOM summary from the browser extension
        /// </summary>
        public async Task<DomSummary?> RequestDomSummaryAsync(int timeoutMs = 5000)
        {
            if (!IsConnected)
            {
                System.Diagnostics.Trace.WriteLine("Cannot request DOM: Browser extension not connected");
                return null;
            }

            // Ensure only one DOM request at a time
            if (!await _domRequestLock.WaitAsync(0))
            {
                System.Diagnostics.Trace.WriteLine("DOM request already in progress, waiting...");
                await _domRequestLock.WaitAsync();
            }

            try
            {
                System.Diagnostics.Trace.WriteLine("Sending REQUEST_DOM to browser extension...");
                _domRequestCompletion = new TaskCompletionSource<DomSummary>();
                
                // Capture the task reference before sending to avoid race condition
                var domTask = _domRequestCompletion.Task;

                await SendMessageAsync(new
                {
                    type = "REQUEST_DOM"
                });

                // Wait for response with timeout
                var completedTask = await Task.WhenAny(
                    domTask,
                    Task.Delay(timeoutMs)
                );

                if (completedTask == domTask)
                {
                    var result = await domTask;
                    System.Diagnostics.Trace.WriteLine($"DOM summary received: {result?.Elements?.Count ?? 0} elements");
                    return result;
                }

                System.Diagnostics.Trace.WriteLine($"DOM request timed out after {timeoutMs}ms");
                
                // Clean up the completion source on timeout
                var oldCompletion = _domRequestCompletion;
                _domRequestCompletion = null;
                oldCompletion?.TrySetCanceled();
                
                return null; // Timeout
            }
            finally
            {
                _domRequestLock.Release();
            }
        }

        /// <summary>
        /// Tell the browser extension to highlight an element
        /// </summary>
        public async Task HighlightElementAsync(string selector, string? color = null, double? thickness = null)
        {
            if (!IsConnected)
            {
                System.Diagnostics.Trace.WriteLine("[BrowserBridge] Cannot highlight element - not connected");
                return;
            }

            System.Diagnostics.Trace.WriteLine($"[BrowserBridge] Sending HIGHLIGHT_ELEMENT - selector: {selector}, color: {color ?? "#00FF00"}, thickness: {thickness ?? 4.0}");

            await SendMessageAsync(new
            {
                type = "HIGHLIGHT_ELEMENT",
                selector = selector,
                color = color ?? "#00FF00",
                thickness = thickness ?? 4.0
            });
        }

        /// <summary>
        /// Clear the highlight in the browser
        /// </summary>
        public async Task ClearHighlightAsync()
        {
            if (!IsConnected) return;
            Trace.WriteLine("Sending CLEAR_HIGHLIGHT to browser extension");
            await SendMessageAsync(new
            {
                type = "CLEAR_HIGHLIGHT"
            });
        }

        /// <summary>
        /// Set browser zoom level based on font size
        /// </summary>
        public async Task SetZoomAsync(string fontSize, bool enabled)
        {
            if (!IsConnected) return;

            await SendMessageAsync(new
            {
                type = "SET_ZOOM",
                fontSize = fontSize,
                enabled = enabled
            });
        }

        /// <summary>
        /// Enable or disable zoom synchronization
        /// </summary>
        public async Task SetZoomEnabledAsync(bool enabled)
        {
            if (!IsConnected) return;

            await SendMessageAsync(new
            {
                type = "SET_ZOOM_ENABLED",
                enabled = enabled
            });
        }

        private async Task RunServerAsync()
        {
            while (_isRunning)
            {
                try
                {
                    _httpListener = new HttpListener();
                    _httpListener.Prefixes.Add("http://localhost:9876/");
                    _httpListener.Start();

                    while (_isRunning)
                    {
                        var context = await _httpListener.GetContextAsync();

                        if (context.Request.IsWebSocketRequest)
                        {
                            // Only accept new connection if no active connection exists
                            if (_webSocket != null && _webSocket.State == WebSocketState.Open)
                            {
                                // Reject new connection - already have an active one
                                context.Response.StatusCode = 409; // Conflict
                                context.Response.Close();
                                System.Diagnostics.Trace.WriteLine("Rejected new WebSocket connection - already connected");
                                continue;
                            }
                            
                            var wsContext = await context.AcceptWebSocketAsync(null);
                            _webSocket = wsContext.WebSocket;
                            System.Diagnostics.Trace.WriteLine("Browser extension WebSocket connected");

                            // Handle WebSocket in background - don't await it so we can accept new connections
                            _ = HandleWebSocketAsync(_webSocket);
                        }
                        else
                        {
                            context.Response.StatusCode = 400;
                            context.Response.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Trace.WriteLine($"WebSocket server error: {ex.Message}");
                    await Task.Delay(3000); // Wait before retry
                }
            }
        }

        private async Task HandleWebSocketAsync(WebSocket webSocket)
        {
            var buffer = new byte[1024 * 16]; // Increased buffer size to 16KB for larger messages
            var messageBuilder = new StringBuilder();

            try
            {
                // Start keepalive timer to send periodic pings
                _keepAliveTimer?.Dispose(); // Dispose any existing timer
                _keepAliveTimer = new Timer(async _ =>
                {
                    if (webSocket.State == WebSocketState.Open)
                    {
                        try
                        {
                            await SendPingAsync(webSocket);
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Trace.WriteLine($"Keepalive ping failed: {ex.Message}");
                        }
                    }
                }, null, TimeSpan.FromMilliseconds(KEEPALIVE_INTERVAL_MS), TimeSpan.FromMilliseconds(KEEPALIVE_INTERVAL_MS));

                while (webSocket.State == WebSocketState.Open && _isRunning)
                {
                    var result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);

                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        System.Diagnostics.Trace.WriteLine($"WebSocket close received - Status: {result.CloseStatus}, Description: {result.CloseStatusDescription}");
                        await webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closing", CancellationToken.None);
                        break;
                    }
                    else if (result.MessageType == WebSocketMessageType.Text)
                    {
                        // Append the received chunk to the message builder
                        var chunk = Encoding.UTF8.GetString(buffer, 0, result.Count);
                        messageBuilder.Append(chunk);

                        // Only process the message when we've received the complete message
                        if (result.EndOfMessage)
                        {
                            var completeMessage = messageBuilder.ToString();
                            messageBuilder.Clear();
                            await HandleIncomingMessageAsync(completeMessage);
                        }
                    }
                }
            }
            catch (WebSocketException wsEx)
            {
                System.Diagnostics.Trace.WriteLine($"WebSocket error: {wsEx.Message} (Code: {wsEx.WebSocketErrorCode})");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine($"WebSocket communication error: {ex.Message}");
            }
            finally
            {
                // Stop keepalive timer
                _keepAliveTimer?.Dispose();
                _keepAliveTimer = null;

                // Clean up when WebSocket closes
                System.Diagnostics.Trace.WriteLine($"WebSocket handler exiting. State: {webSocket.State}");
                
                // If this was the current WebSocket and it's no longer open, clear it
                if (_webSocket == webSocket && webSocket.State != WebSocketState.Open)
                {
                    _webSocket = null;
                    System.Diagnostics.Trace.WriteLine("Browser extension WebSocket disconnected");
                }
                
                // Ensure WebSocket is properly closed
                if (webSocket.State == WebSocketState.Open)
                {
                    try
                    {
                        await webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Handler exiting", CancellationToken.None);
                    }
                    catch { }
                }
            }
        }

        private async Task HandleIncomingMessageAsync(string messageJson)
        {
            try
            {
                // Check if message is empty or whitespace
                if (string.IsNullOrWhiteSpace(messageJson))
                {
                    System.Diagnostics.Trace.WriteLine("Received empty message from browser");
                    return;
                }

                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                };
                var message = JsonSerializer.Deserialize<BrowserMessage>(messageJson, options);

                if (message == null)
                {
                    System.Diagnostics.Trace.WriteLine("Failed to deserialize browser message");
                    return;
                }

                // Check if Type is null or empty
                if (string.IsNullOrWhiteSpace(message.Type))
                {
                    System.Diagnostics.Trace.WriteLine($"Received message with empty type. Message JSON: {messageJson}");
                    return;
                }

                switch (message.Type)
                {
                    case "DOM_SUMMARY":
                        System.Diagnostics.Trace.WriteLine("Received DOM_SUMMARY from browser extension");
                        if (message.Data != null)
                        {
                            var domJson = JsonSerializer.Serialize(message.Data);
                            var domOptions = new JsonSerializerOptions
                            {
                                PropertyNameCaseInsensitive = true
                            };
                            _lastDomSummary = JsonSerializer.Deserialize<DomSummary>(domJson, domOptions);

                            if (_lastDomSummary != null)
                            {
                                System.Diagnostics.Trace.WriteLine($"Parsed DOM summary: URL={_lastDomSummary.Url}, Elements={_lastDomSummary.Elements.Count}");
                            }

                            if (_domRequestCompletion != null && _lastDomSummary != null)
                            {
                                _domRequestCompletion.TrySetResult(_lastDomSummary);
                                _domRequestCompletion = null;
                            }
                        }
                        else
                        {
                            System.Diagnostics.Trace.WriteLine("DOM_SUMMARY message had null Data");
                        }
                        break;

                    case "CONNECTION_STATUS":
                        System.Diagnostics.Trace.WriteLine($"Browser extension connected: {message.Connected}");
                        break;

                    case "ERROR":
                        System.Diagnostics.Trace.WriteLine($"Browser extension error: {message.Message}");
                        break;

                    case "HIGHLIGHT_SUCCESS":
                    case "ZOOM_SUCCESS":
                    case "PONG":
                        // Acknowledge success messages silently
                        break;

                    default:
                        System.Diagnostics.Trace.WriteLine($"Unknown message type: '{message.Type}' (JSON: {messageJson})");
                        break;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine($"Error handling message: {ex.Message}. JSON: {messageJson}");
            }

            await Task.CompletedTask;
        }

        private async Task SendMessageAsync(object message)
        {
            if (_webSocket == null || _webSocket.State != WebSocketState.Open)
            {
                return;
            }

            try
            {
                var json = JsonSerializer.Serialize(message);
                var bytes = Encoding.UTF8.GetBytes(json);
                await _webSocket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine($"Error sending message: {ex.Message}");
            }
        }

        private async Task SendPingAsync(WebSocket webSocket)
        {
            if (webSocket.State != WebSocketState.Open)
            {
                return;
            }

            try
            {
                var json = JsonSerializer.Serialize(new { type = "PING" });
                var bytes = Encoding.UTF8.GetBytes(json);
                await webSocket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine($"Error sending ping: {ex.Message}");
            }
        }
    }
}
